# Sistema de Almoxarifado

Versão inicial do aplicativo web para controle de entradas, saídas, estoque e logística.

## Como usar
Abra o arquivo `index.html` no navegador. Os registros desta versão ficam salvos no navegador do dispositivo.

## Próxima etapa
Conectar a um banco de dados compartilhado para que todos os usuários visualizem as mesmas movimentações.
